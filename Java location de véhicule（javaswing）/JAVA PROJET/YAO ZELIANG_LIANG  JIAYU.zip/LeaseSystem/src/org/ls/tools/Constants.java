package org.ls.tools;

/**
 * 常量类
 */
public class Constants {
	
	/**
	 * 窗体的宽度和高度
	 */
	public static final int WIDTH = 950;
	public static final int HEIGHT = 600;
	
	public static final int MOTO=1;
	public static final int AUTO=0;

}
